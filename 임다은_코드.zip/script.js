document.addEventListener("DOMContentLoaded", function () {
  const textLines = [
    "안녕하세요 :D",
    "창의적인 사고를 할 수 있는",
    "프론트엔드 개발자 임다은입니다.",
  ];
  let currentLineIndex = 0;
  let currentCharIndex = 0;
  let isDeleting = false;
  const typingElement = document.querySelector(".main_info");
  const typingSpeed = 100; // 타이핑 속도 (밀리초 단위)
  const deletingSpeed = 60; // 삭제 속도 (밀리초 단위)
  const pauseDuration = 1000; // 삭제 또는 다음 줄 타이핑 전 대기 시간 (밀리초 단위)

  function type() {
    if (!isDeleting) {
      let currentText = textLines[currentLineIndex].slice(
        0,
        ++currentCharIndex
      );
      let displayedText =
        textLines.slice(0, currentLineIndex).join("<br/>") +
        (currentLineIndex > 0 ? "<br/>" : "") +
        currentText;
      typingElement.innerHTML = displayedText;
      if (currentCharIndex === textLines[currentLineIndex].length) {
        if (currentLineIndex === textLines.length - 1) {
          setTimeout(() => {
            isDeleting = true;
          }, pauseDuration); // 삭제 전 대기 시간
        } else {
          currentLineIndex++;
          currentCharIndex = 0;
          setTimeout(type, pauseDuration); // 다음 줄 타이핑 전 대기 시간
          return;
        }
      }
    } else {
      let currentText = textLines[currentLineIndex].slice(
        0,
        --currentCharIndex
      );
      let displayedText =
        textLines.slice(0, currentLineIndex).join("<br/>") +
        (currentLineIndex > 0 ? "<br/>" : "") +
        currentText;
      typingElement.innerHTML = displayedText;
      if (currentCharIndex === 0) {
        if (currentLineIndex === 0) {
          isDeleting = false;
          setTimeout(type, pauseDuration); // 타이핑 시작 전 대기 시간
          return;
        } else {
          currentLineIndex--;
          currentCharIndex = textLines[currentLineIndex].length;
          setTimeout(type, pauseDuration); // 이전 줄 삭제 전 대기 시간
          return;
        }
      }
    }
    setTimeout(type, isDeleting ? deletingSpeed : typingSpeed); // 일정한 속도로 타이핑 및 삭제
  }

  type();

  createShapes();

  // 모달 닫기 아이콘에 대한 이벤트 리스너 추가
  const closeIcon = document.querySelector(".close-icon");
  const itemsModal = document.querySelector(".items");

  closeIcon.addEventListener("click", () => {
    itemsModal.classList.remove("active");
    document.querySelectorAll(".modal-content").forEach((content) => {
      content.classList.remove("active");
    });
  });
});

function createShapes() {
  const shapeContainer = document.querySelector(".background-animation");
  const shapeTypes = ["shape1", "shape2", "shape3"];

  for (let i = 0; i < 20; i++) {
    // 도형 개수를 늘림
    const shapeType = shapeTypes[Math.floor(Math.random() * shapeTypes.length)];
    const shape = document.createElement("div");
    shape.classList.add("shape", shapeType);
    resetShapePosition(shape);
    shapeContainer.appendChild(shape);
  }
}

function resetShapePosition(shape) {
  const screenWidth = window.innerWidth;
  const randomX = Math.random() * screenWidth;
  shape.style.left = `${randomX}px`; // 백틱을 사용하여 문자열 템플릿 리터럴을 만듭니다.
}

document.addEventListener("DOMContentLoaded", () => {
  const aboutButton = document.querySelector(".main_title_btn");
  const itemsModal = document.querySelector(".items");

  // ABOUT 버튼 클릭 이벤트 추가
  aboutButton.addEventListener("click", () => {
    itemsModal.classList.add("active");
    const closeIcon = document.querySelector(".close-icon");
    closeIcon.style.display = "block";
  });
});

document.addEventListener("DOMContentLoaded", function () {
  // 기존 코드 유지
  // 모달 닫기 아이콘에 대한 이벤트 리스너 추가
  const closeIcon = document.querySelector(".close-icon");
  const itemsModal = document.querySelector(".items");

  closeIcon.addEventListener("click", () => {
    itemsModal.classList.remove("active");
    document.querySelectorAll(".modal-content").forEach((content) => {
      content.classList.remove("active");
    });
  });
});

// 메뉴 클릭시 이벤트 추가
document.addEventListener("DOMContentLoaded", function () {
  // 모든 네비게이션 링크 가져오기
  const navLinks = document.querySelectorAll(".gnbDesktop a");
  // 모든 콘텐츠 섹션 가져오기
  const contentSections = document.querySelectorAll(
    "#skills-content, #projects-content, #contact-content"
  );

  // 각 링크에 이벤트 리스너 추가
  navLinks.forEach((link) => {
    link.addEventListener("click", function (event) {
      event.preventDefault(); // 기본 링크 동작 방지

      // 링크의 href 속성에서 대상 섹션 ID 가져오기
      const targetId = link.getAttribute("href");

      // 모든 콘텐츠 섹션 숨기기
      contentSections.forEach((section) => {
        section.style.display = "none";
      });

      // 대상 콘텐츠 섹션 표시
      const targetSection = document.getElementById(targetId);
      if (targetSection) {
        targetSection.style.display = "block";
      }
    });
  });
});

document.addEventListener("DOMContentLoaded", function () {
  // 모든 네비게이션 링크와 콘텐츠 섹션 가져오기
  const navLinks = document.querySelectorAll(
    ".gnbDesktop a, .gnbMobile a, main_title_btn"
  );
  const contentSections = document.querySelectorAll(
    "#skills-content, #projects-content, #contact-content, .close-icon"
  );
  const closeIcon = document.querySelector(".gnbDesktop .close-icon");

  // 모든 콘텐츠 섹션과 닫기 아이콘 초기 숨기기
  contentSections.forEach((section) => (section.style.display = "none"));
  closeIcon.style.display = "none";

  // 모든 콘텐츠 섹션 숨기기 함수
  function hideAllSections() {
    contentSections.forEach((section) => (section.style.display = "none"));
  }

  // 대상 섹션 표시 함수
  function showSection(targetId) {
    hideAllSections();
    const targetSection = document.getElementById(targetId);
    if (targetSection) {
      targetSection.style.display = "block";
    }
  }

  // 각 네비게이션 링크에 이벤트 리스너 추가
  navLinks.forEach((link) => {
    link.addEventListener("click", function (event) {
      event.preventDefault(); // 기본 링크 동작 방지

      // 링크의 href 속성에서 대상 섹션 ID 가져오기
      const targetId = link.getAttribute("href");

      // 대상 콘텐츠 섹션 표시
      showSection(targetId);

      // 닫기 아이콘 표시
      closeIcon.style.display = "block";
    });
  });

  // Skill, Project, Contact 닫기 아이콘에 대한 이벤트 리스너 추가
  const closeNavIcons = document.querySelectorAll(
    ".gnbDesktop .close-icon, .gnbMobile .close-icon"
  );

  closeNavIcons.forEach((closeIcon) => {
    closeIcon.addEventListener("click", function () {
      contentSections.forEach((section) => {
        section.style.display = "none";
      });
    });
  });
});

const btns = document.querySelector(".controls");
const prevBtn = btns.querySelector(".prev");
const nextBtn = btns.querySelector(".next");

const slides = document.querySelector(".slides");
const slide = slides.querySelectorAll("li");

const slideCount = slide.length;
const slideWidth = 200;
const slideMargin = 30;

let currentIdx = 0;

// 복제한 5개의 li노드를 왼쪽으로 이동시키기 위한 함수(1)
const updateWidth = () => {
  const currentSlides = document.querySelectorAll(".slides li");
  const newSlideCount = currentSlides.length;
  const newWidth = `${
    (slideWidth + slideMargin) * newSlideCount - slideMargin
  }px`;
  slides.style.width = newWidth;
};

// 복제한 5개의 li노드를 왼쪽으로 이동시키기 위한 함수(2)
const setInitialPos = () => {
  const initialTranslateValue = -(slideWidth + slideMargin) * slideCount;
  slides.style.transform = `translateX(${initialTranslateValue}px)`;
};

// li노드를 복제하기 위한 함수
const makeClone = () => {
  for (let i = 0; i < slideCount; i++) {
    const cloneSlide = slide[i].cloneNode(true);
    cloneSlide.classList.add("clone");
    slides.appendChild(cloneSlide);
  }
  for (let i = slideCount - 1; i >= 0; i--) {
    const cloneSlide = slide[i].cloneNode(true);
    cloneSlide.classList.add("clone");
    slides.prepend(cloneSlide);
  }

  updateWidth();
  setInitialPos();
  setTimeout(() => {
    slides.classList.add("animated");
  }, 100);
};

makeClone();

// 버튼 클릭을 통해서 실제 슬라이드를 출력시켜주는 함수
const moveSlide = (num) => {
  slides.style.left = `${-num * (slideWidth + slideMargin)}px`;
  currentIdx = num;
  if (currentIdx === slideCount || currentIdx === -slideCount) {
    setTimeout(() => {
      slides.classList.remove("animated");
      slides.style.left = "0px";
      currentIdx = 0;
    }, 500);
    setTimeout(() => {
      slides.classList.add("animated");
    }, 600);
  }
};

// 버튼 클릭 이벤트 함수
nextBtn.addEventListener("click", () => {
  moveSlide(currentIdx + 1);
});

prevBtn.addEventListener("click", () => {
  moveSlide(currentIdx - 1);
});

// 자동슬라이드 및 정지기능 함수

let timer = undefined;

const autoSlide = () => {
  if (timer === undefined) {
    timer = setInterval(() => {
      moveSlide(currentIdx + 1);
    }, 3000);
  }
};

autoSlide();

const stopSlide = () => {
  clearInterval(timer);
  timer = undefined;
};

slides.addEventListener("mouseenter", () => {
  stopSlide();
});

slides.addEventListener("mouseleave", () => {
  autoSlide();
});

btns.addEventListener("mouseenter", () => {
  stopSlide();
});

btns.addEventListener("mouseleave", () => {
  autoSlide();
});
